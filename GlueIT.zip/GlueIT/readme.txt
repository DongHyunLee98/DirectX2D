GlueIT 1.04 by Yves Plouffe, July 2006


Version History

...........................................................
V 1.02 April 2006

  Core re-write using .NET 2.0
  Additional file format support, .PNG .JPG .BMP
  Streamlined interface as per user requests

...........................................................
V 1.04 July 4 2006

  Added a Project system, user request
  Optimizations and minor bug fixes

...........................................................
V 1.06 July 5 2006

  Further enhanced .PNGs support, now preserves all transparency information
  
...........................................................

Getting started,

Launch GlueIT,
  - Click on ADD and select a few images, make sure all images are the same size.
    GlueIT will take the dimentions of the first image and use that for the rest of the     sequence.

  - In the File list box, move your sequence around until you're happy with the sequence.
  - Enter the number of columns you want your final glued image to have.
  - Hit GlueIT.

You can change the number of columns again without reloading everything, just change and hit the glueIT button again

Once Glued, hit the preview anim buton.

To save to a new format, .PNG .BMP, .JPG, just make sure you use the pulldown filter selector in the save dialog box, GlueIT will do the appropriate conversion.

That's it.

I can be reached at yves_plouffe@yahoo.ca

Thanks, Yves,

aka Gunner, Kreegrr